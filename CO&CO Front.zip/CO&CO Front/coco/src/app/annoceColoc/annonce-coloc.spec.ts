import { AnnonceColoc } from './annonce-coloc';

describe('AnnonceColoc', () => {
  it('should create an instance', () => {
    expect(new AnnonceColoc()).toBeTruthy();
  });
});
