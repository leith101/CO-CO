package com.example.testeditions.Entites;

public class schedule {
}
