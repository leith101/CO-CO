package com.example.testeditions.Repositories;

import com.example.testeditions.Entites.Reponse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReponseRepository extends JpaRepository<Reponse, Integer> {
}
