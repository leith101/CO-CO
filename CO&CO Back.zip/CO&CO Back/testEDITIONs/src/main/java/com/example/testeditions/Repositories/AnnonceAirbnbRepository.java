package com.example.testeditions.Repositories;

import com.example.testeditions.Entites.AnnonceAirbnb;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnnonceAirbnbRepository extends JpaRepository<AnnonceAirbnb, Long> {
}
