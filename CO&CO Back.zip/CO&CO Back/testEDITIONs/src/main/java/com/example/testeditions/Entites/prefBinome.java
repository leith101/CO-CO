package com.example.testeditions.Entites;

public enum prefBinome {
    pet_lover,
    non_smoker,
    alcahoolic,
    smoker,
    sport,
    cars
}
