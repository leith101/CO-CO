package com.example.testeditions.Entites;


public enum StateLike {
    like , dislike,Love,Haha}
