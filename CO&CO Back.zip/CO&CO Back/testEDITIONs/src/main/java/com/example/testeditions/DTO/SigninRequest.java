package com.example.testeditions.DTO;

import lombok.Data;

@Data
public class SigninRequest {

    private String email;
    private String password;
}
