package com.example.testeditions.Repositories;

import com.example.testeditions.Entites.Matchs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatchRepository extends JpaRepository<Matchs,Long> {


}
