package com.example.testeditions.Entites;

public enum choixC {
    choix1,
    choix2,
    choix3

}
