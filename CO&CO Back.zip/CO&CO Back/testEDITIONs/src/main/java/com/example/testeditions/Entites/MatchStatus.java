package com.example.testeditions.Entites;

public enum MatchStatus {
    LIKE,DISLIKE
}
