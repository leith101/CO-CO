package com.example.testeditions.Entites;

public enum TypeRole {
    admin,utilisateur
}
