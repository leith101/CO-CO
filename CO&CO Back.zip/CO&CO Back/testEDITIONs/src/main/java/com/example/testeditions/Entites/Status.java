package com.example.testeditions.Entites;

public enum Status {
    DISPONIBLE,
    NON_DISPONIBLE
}
