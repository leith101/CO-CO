package com.example.testeditions.Entites;

public enum TypeLocal {
     Studio,
    Apartment ,
     House ,
    Duplex ,
     villa ,
     cabin

}
