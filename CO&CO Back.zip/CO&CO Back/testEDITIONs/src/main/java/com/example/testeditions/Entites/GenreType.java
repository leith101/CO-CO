package com.example.testeditions.Entites;

public enum GenreType {
    Homme,femme
}
