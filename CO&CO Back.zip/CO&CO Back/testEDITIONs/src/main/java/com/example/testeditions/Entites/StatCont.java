package com.example.testeditions.Entites;

public enum StatCont {
    ContratDeLocation,
    ContratDeColocation,

}
