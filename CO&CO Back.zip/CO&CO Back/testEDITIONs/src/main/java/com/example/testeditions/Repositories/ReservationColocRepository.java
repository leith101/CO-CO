package com.example.testeditions.Repositories;

import com.example.testeditions.Entites.ReservationColoc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationColocRepository extends JpaRepository<ReservationColoc, Long> {
}
