package com.example.testeditions.Entites;

public enum TypeLocale {

    PLAGES,
    LUXE,
    ART_CREATIVITE,
    PARCS_NATIONAUX,
    ILES
}
