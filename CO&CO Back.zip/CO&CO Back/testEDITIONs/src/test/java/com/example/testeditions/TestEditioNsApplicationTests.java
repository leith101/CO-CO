package com.example.testeditions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestEditioNsApplicationTests {

    @Test
    void contextLoads() {
    }

}
